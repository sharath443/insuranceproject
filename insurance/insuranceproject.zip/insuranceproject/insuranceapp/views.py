from django.http import HttpResponse, HttpResponseRedirect
import random
import string
from django.shortcuts import render
from .models import student_frm,firemodel,vmodel
from .forms import formclass,fire_frm
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from .forms import SignUpForm, vehicle_frm

def show_data(request):
    if request.method == 'POST':
        fm = formclass(request.POST)
        if fm.is_valid():
            polacy_no = int(''.join(random.choice(string.digits) for n in range(10)))
            name = fm.cleaned_data['name']
            fname = fm.cleaned_data['fname']
            age = fm.cleaned_data['age']
            gender = fm.cleaned_data['gender']
            date_brth = fm.cleaned_data['date_brth']
            email = fm.cleaned_data['email']
            address = fm.cleaned_data['address']
            phone_no = fm.cleaned_data['phone_no']
            reg = student_frm(polacy_no = polacy_no,name= name,fname= fname,age=age,gender=gender, date_brth= date_brth,email=email,address=address,phone_no=phone_no,)
            reg.save()
            fm = formclass()
    else:
        fm = formclass()
    return render(request, 'index.html',{'forms':fm,'data1':student_frm.objects.all()})

def vshow_data(request):
    if request.method == 'POST':
        fm = vehicle_frm(request.POST)
        if fm.is_valid():
            polacy_no = int(''.join(random.choice(string.digits) for n in range(10)))
            vehicle_no = fm.cleaned_data['vehicle_no']
            owner_name = fm.cleaned_data['owner_name']
            vehicle_wheel = fm.cleaned_data['vehicle_wheel']
            vehicle_name = fm.cleaned_data['vehicle_name']
            vehicle_date = fm.cleaned_data['vehicle_date']
            email = fm.cleaned_data['email']
            address = fm.cleaned_data['address']
            phone_no = fm.cleaned_data['phone_no']
            reg = vmodel(polacy_no = polacy_no,vehicle_no = vehicle_no,owner_name= owner_name, vehicle_wheel=vehicle_wheel ,vehicle_name=vehicle_name, vehicle_date= vehicle_date,email=email,address=address,phone_no=phone_no,)
            reg.save()
            fm = vehicle_frm()
    else:
        fm = vehicle_frm()
    return render(request, 'index.html',{'forms':fm,'data2':student_frm.objects.all()})

def fshow_data(request):
    if request.method == 'POST':
        fm = fire_frm(request.POST)
        if fm.is_valid():
            polacy_no = int(''.join(random.choice(string.digits) for n in range(10)))
            type_property = fm.cleaned_data['type_property']
            owner_name = fm.cleaned_data['owner_name']
            vehicle_wheel = fm.cleaned_data['vehicle_wheel']
            cause_name = fm.cleaned_data['cause_name']
            fire_date = fm.cleaned_data['fire_date']
            email = fm.cleaned_data['email']
            address = fm.cleaned_data['address']
            phone_no = fm.cleaned_data['phone_no']
            reg = firemodel(polacy_no = polacy_no,type_property = type_property,owner_name= owner_name,vehicle_wheel=vehicle_wheel,cause_name=cause_name, fire_date= fire_date,email=email,address=address,phone_no=phone_no,)
            reg.save()
            fm = fire_frm()
    else:
        fm = fire_frm()
    return render(request, 'index.html',{'forms':fm,'data3':student_frm.objects.all()})



def update_data(request,id):
        pi = student_frm.objects.get(pk=id)
        fm = formclass(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
        else:
            pi = student_frm.objects.get(pk=id)
            fm = formclass(instance=pi)
        return render(request,'index.html',{'forms':fm})

def delete_data(request,id):

    if request.method == 'POST':
        pi = student_frm.objects.get(pk = id)
        print(pi)
        pi.delete()
        return HttpResponseRedirect('/show_data')


def sign_up(request):
    if request.method == 'POST':
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            messages.success(request,"created Done")
            fm.save()
    else:
        fm =SignUpForm()
    return render(request,'signup.html',{'form':fm})


def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request=request, data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'Logged in Succesfully !!!')
                    return HttpResponseRedirect('home')
        else:
            fm = AuthenticationForm()
            return render(request, 'login.html', {'form': fm})
    else:
        return HttpResponseRedirect('user_login')

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/user_login')

def home(request):
    if request.user.is_authenticated:
        return render(request, 'home.html')