from django.contrib import admin
from .models import student_frm, firemodel, vmodel


# @admin.register(student_frm)
# class sdata(admin.ModelAdmin):
#     list_display = '__all__'
#
#
# @admin.register(vmodel)
# class vdata(admin.ModelAdmin):
#     list_display = '__all__'


@admin.register(firemodel)
class fdata(admin.ModelAdmin):
    list_display = ['owner_name']
