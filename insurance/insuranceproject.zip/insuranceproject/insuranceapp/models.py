from django.db import models


class student_frm(models.Model):
    polacy_no = models.IntegerField(null=True)
    name = models.CharField(max_length=10, null=True)
    fname = models.CharField(max_length=10, null=True)
    age = models.IntegerField(null=True)
    gender = models.CharField(max_length=10, null=True)
    date_brth = models.DateField(null=True)
    email = models.EmailField(null=True)
    address = models.CharField(max_length=50, null=True)
    phone_no = models.IntegerField(null=True)


class vmodel(models.Model):
    polacy_no = models.IntegerField(null=True)
    vehicle_no = models.IntegerField(null=True)
    owner_name = models.CharField(max_length=10, null=True)
    vehicle_wheel = models.IntegerField(null=True)
    vehicle_name = models.CharField(max_length=10, null=True)
    vehicle_date = models.DateField(null=True)
    email = models.EmailField(null=True)
    address = models.CharField(max_length=50, null=True)
    phone_no = models.IntegerField(null=True)


class firemodel(models.Model):
    polacy_no = models.IntegerField(null=True)
    type_property = models.CharField(max_length=40)
    owner_name = models.CharField(max_length=10, null=True)
    vehicle_wheel = models.IntegerField(null=True)
    cause_name = models.CharField(max_length=10, null=True)
    fire_date = models.DateField(null=True)
    email = models.EmailField(null=True)
    address = models.CharField(max_length=50, null=True)
    phone_no = models.IntegerField(null=True)

    def __str__(self):
        return self.polacy_no, self.phone_no,self.vehicle_wheel
